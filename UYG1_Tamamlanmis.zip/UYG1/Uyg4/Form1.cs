﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Uyg4
{
    public partial class Form1 : Form
    {
        int zar1, zar2;
        int adim = 6;
        public Form1()
        {
            InitializeComponent();
        }

     
        private void zarAtButon_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            lblToplam.Text = "?";

            lblCarpim.Text = "?";

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            adim--;
           
            Random rst = new Random();
            zar1 = rst.Next(0, 5);
            zar2 = rst.Next(0, 5);
            pictureBox1.Image = imageList1.Images[zar1];
            pictureBox2.Image = imageList1.Images[zar2];
            if (adim == 0)
            {
                timer1.Enabled = false;
                lblToplam.Text = (zar1 + 1 + zar2 + 1).ToString();

                lblCarpim.Text = ((zar1 + 1) * (zar2 + 1)).ToString();
                adim = 6;
            }
        }

  
    }
}
