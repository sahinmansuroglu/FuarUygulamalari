﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        int kalanHak;
        int bilgisayarinTuttuguSayi;
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        

      

        private void yeniOyunButon_Click(object sender, EventArgs e)
        {
            Random randomNesne = new Random();
            bilgisayarinTuttuguSayi = randomNesne.Next(1, 100);
            kalanHak = 5;
            lblKalanHak.Text = kalanHak.ToString(); ;
            lblTutulanSayi.Text = "?";
            txtSayiKutu.Enabled = true;
            txtSayiKutu.Focus();
            sayiListesi.Items.Clear();

        }

        private void kontrolEtButon_Click(object sender, EventArgs e)
        {
            kalanHak--;
            if (kalanHak >= 0)
            {
                lblKalanHak.Text = kalanHak.ToString(); ;
                int girilenSayi = Convert.ToInt32(txtSayiKutu.Text);
                sayiListesi.Items.Add(girilenSayi.ToString());


                if (bilgisayarinTuttuguSayi < girilenSayi)
                {
                    lblDurum.Text = "Azalt";
                }
                else if (bilgisayarinTuttuguSayi > girilenSayi)
                {
                    lblDurum.Text = "Arttır";
                }
                else
                {
                    lblDurum.Text = "Tebrikler";
                    lblTutulanSayi.Text = bilgisayarinTuttuguSayi.ToString();
                    txtSayiKutu.Enabled = false;
                }
                txtSayiKutu.Clear();
                txtSayiKutu.Focus();

            }
            else
            {
                lblTutulanSayi.Text = bilgisayarinTuttuguSayi.ToString();
                lblDurum.Text = "Kaybettiniz";
                MessageBox.Show("Üzgünüm Kaybettiniz...");
                txtSayiKutu.Enabled = false;

            }

        }
    }
}
