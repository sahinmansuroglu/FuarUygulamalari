﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.yeniOyunButon = new System.Windows.Forms.Button();
            this.lblTutulanSayi = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSayiKutu = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblKalanHak = new System.Windows.Forms.Label();
            this.lblDurum = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.kontrolEtButon = new System.Windows.Forms.Button();
            this.sayiListesi = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Gray;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.Location = new System.Drawing.Point(752, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(36, 31);
            this.button2.TabIndex = 12;
            this.button2.Text = "X";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // yeniOyunButon
            // 
            this.yeniOyunButon.BackColor = System.Drawing.Color.Gray;
            this.yeniOyunButon.FlatAppearance.BorderSize = 0;
            this.yeniOyunButon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.yeniOyunButon.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.yeniOyunButon.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.yeniOyunButon.Location = new System.Drawing.Point(12, 12);
            this.yeniOyunButon.Name = "yeniOyunButon";
            this.yeniOyunButon.Size = new System.Drawing.Size(150, 31);
            this.yeniOyunButon.TabIndex = 13;
            this.yeniOyunButon.Text = "Yeni Oyun";
            this.yeniOyunButon.UseVisualStyleBackColor = false;
            this.yeniOyunButon.Click += new System.EventHandler(this.yeniOyunButon_Click);
            // 
            // lblTutulanSayi
            // 
            this.lblTutulanSayi.BackColor = System.Drawing.Color.Transparent;
            this.lblTutulanSayi.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTutulanSayi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblTutulanSayi.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTutulanSayi.Location = new System.Drawing.Point(296, 97);
            this.lblTutulanSayi.Name = "lblTutulanSayi";
            this.lblTutulanSayi.Size = new System.Drawing.Size(155, 200);
            this.lblTutulanSayi.TabIndex = 14;
            this.lblTutulanSayi.Text = "?";
            this.lblTutulanSayi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(282, 330);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(196, 20);
            this.label2.TabIndex = 15;
            this.label2.Text = "0-100 Arası Sayı Giriniz";
            // 
            // txtSayiKutu
            // 
            this.txtSayiKutu.Enabled = false;
            this.txtSayiKutu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSayiKutu.Location = new System.Drawing.Point(316, 362);
            this.txtSayiKutu.Name = "txtSayiKutu";
            this.txtSayiKutu.Size = new System.Drawing.Size(120, 30);
            this.txtSayiKutu.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(6, 413);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 25);
            this.label3.TabIndex = 17;
            this.label3.Text = "Kalan Hakkınız :";
            // 
            // lblKalanHak
            // 
            this.lblKalanHak.AutoSize = true;
            this.lblKalanHak.BackColor = System.Drawing.Color.Transparent;
            this.lblKalanHak.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKalanHak.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblKalanHak.Location = new System.Drawing.Point(165, 411);
            this.lblKalanHak.Name = "lblKalanHak";
            this.lblKalanHak.Size = new System.Drawing.Size(29, 31);
            this.lblKalanHak.TabIndex = 18;
            this.lblKalanHak.Text = "?";
            // 
            // lblDurum
            // 
            this.lblDurum.BackColor = System.Drawing.Color.Transparent;
            this.lblDurum.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDurum.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblDurum.Location = new System.Drawing.Point(663, 409);
            this.lblDurum.Name = "lblDurum";
            this.lblDurum.Size = new System.Drawing.Size(124, 32);
            this.lblDurum.TabIndex = 20;
            this.lblDurum.Text = "?";
            this.lblDurum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(585, 413);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 25);
            this.label5.TabIndex = 19;
            this.label5.Text = "Durum :";
            // 
            // kontrolEtButon
            // 
            this.kontrolEtButon.BackColor = System.Drawing.Color.Firebrick;
            this.kontrolEtButon.FlatAppearance.BorderSize = 0;
            this.kontrolEtButon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.kontrolEtButon.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kontrolEtButon.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.kontrolEtButon.Location = new System.Drawing.Point(301, 398);
            this.kontrolEtButon.Name = "kontrolEtButon";
            this.kontrolEtButon.Size = new System.Drawing.Size(150, 31);
            this.kontrolEtButon.TabIndex = 21;
            this.kontrolEtButon.Text = "Kontrol Et";
            this.kontrolEtButon.UseVisualStyleBackColor = false;
            this.kontrolEtButon.Click += new System.EventHandler(this.kontrolEtButon_Click);
            // 
            // sayiListesi
            // 
            this.sayiListesi.BackColor = System.Drawing.Color.DarkOrange;
            this.sayiListesi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sayiListesi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sayiListesi.ItemHeight = 20;
            this.sayiListesi.Location = new System.Drawing.Point(765, 97);
            this.sayiListesi.Name = "sayiListesi";
            this.sayiListesi.Size = new System.Drawing.Size(34, 202);
            this.sayiListesi.TabIndex = 22;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.yellow_orange_background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.sayiListesi);
            this.Controls.Add(this.kontrolEtButon);
            this.Controls.Add(this.lblDurum);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblKalanHak);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSayiKutu);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblTutulanSayi);
            this.Controls.Add(this.yeniOyunButon);
            this.Controls.Add(this.button2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button yeniOyunButon;
        public System.Windows.Forms.Label lblTutulanSayi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSayiKutu;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblKalanHak;
        private System.Windows.Forms.Label lblDurum;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button kontrolEtButon;
        private System.Windows.Forms.ListBox sayiListesi;
    }
}

