﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Nakov.TurtleGraphics;
namespace Uyg2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       


        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cizHesaplaButon_Click(object sender, EventArgs e)
        {
            cizHesaplaButon.Enabled = false;
            int kisaKenar = Int32.Parse(txtKisaKenar.Text);
            int uzunKenar = Int32.Parse(txtUzunKenar.Text);
            Turtle.Reset();
            Turtle.Delay = 250;//100-300
            Turtle.PenColor = System.Drawing.Color.White;
            Turtle.PenSize = 3;
            for (int i = 0; i < 2; i++)
            {
                Turtle.Forward(kisaKenar);
                Turtle.Rotate(90);
                Turtle.Forward(uzunKenar);
                Turtle.Rotate(90);
            }



            txtAlan.Text = (uzunKenar * kisaKenar).ToString();
            txtCevre.Text = ((uzunKenar + kisaKenar) * 2).ToString();
            cizHesaplaButon.Enabled = true;
        }
    }
}
