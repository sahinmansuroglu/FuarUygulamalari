﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UYG1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void mesajOlusturButton_Click(object sender, EventArgs e)
        {
            string sehirAdi = txtSehirAdi.Text;
            string enGuzelYeri = txtEnGuzelYeri.Text;
            string neYenir = txtEnGuzelYemegi.Text;
            string mesaj = $"{sehirAdi} şehrinin en güzel yeri {enGuzelYeri}, en güzel Yiyeceği de {neYenir}.";
            MessageBox.Show(mesaj, "Mesaj", MessageBoxButtons.OK, MessageBoxIcon.Information);
            lstMesaj.Items.Add(mesaj);
            txtEnGuzelYemegi.Clear();
            txtEnGuzelYeri.Clear();
            txtSehirAdi.Clear();
            txtSehirAdi.Focus();
        }

        private void cikisButon_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
